package com.nexus.HapiTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HapiTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HapiTestApplication.class, args);
	}

}
